<?php
include('../config/connect.php');
include 'navbar.php';

// Fetch the total count of members from the user_info table
$queryMembers = "SELECT COUNT(*) AS total_members FROM user_info";
$resultMembers = mysqli_query($conn, $queryMembers);
$total_members = 0;
if ($resultMembers && mysqli_num_rows($resultMembers) > 0) {
    $rowMembers = mysqli_fetch_assoc($resultMembers);
    $total_members = $rowMembers['total_members'];
}

// Query to count borrowed books
$sqlBorrowedBooksCount = "SELECT COUNT(*) AS borrowed_books_count FROM borrowed_books";
$resultBorrowedBooksCount = $conn->query($sqlBorrowedBooksCount);

$borrowedBooksCount = 0;
if ($resultBorrowedBooksCount && $resultBorrowedBooksCount->num_rows > 0) {
    $row = $resultBorrowedBooksCount->fetch_assoc();
    $borrowedBooksCount = $row['borrowed_books_count'];
}

// Query to count returned books
$sqlReturnedBooksCount = "SELECT COUNT(*) AS returned_books_count FROM returned_books";
$resultReturnedBooksCount = $conn->query($sqlReturnedBooksCount);

$returnedBooksCount = 0;
if ($resultReturnedBooksCount && $resultReturnedBooksCount->num_rows > 0) {
    $row = $resultReturnedBooksCount->fetch_assoc();
    $returnedBooksCount = $row['returned_books_count'];
}

// Query to fetch borrowed books for the table display (no lender_id used)
$sql = "SELECT name, title, borrow_date, due_date FROM borrowed_books";
$result = $conn->query($sql);

$borrowedBooks = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $borrowedBooks[] = $row;
    }
}

// Fetch overdue books (no lender_id used)
$sql = "SELECT book_id, title, name, due_date
        FROM borrowed_books
        WHERE due_date < CURDATE() AND status != 'returned'";
$result = $conn->query($sql);

// Check if there are any overdue books
$overdueBooks = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $overdueBooks[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Dashboard</title>
    <link rel="stylesheet" href="ldr_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="dashboard-container">
    <div class="header-container">
        <h1 class="dashboard-overview-title">OVERVIEW</h1>
        <?php if (!empty($overdueBooks)) : ?>
        <div class="overdue-notification" id="overdueNotification">
            <div class="overdue-text">OVERDUE BOOKS</div>
            <div class="bell-container">
                <i class="fas fa-bell bell"></i>
                <div class="notifications-badge"><?php echo count($overdueBooks); ?></div>
            </div>
            <div class="overdue-dropdown" id="overdueDropdown">
                <div class="overdue-dropdown-header">
                    Overdue Books (<?php echo count($overdueBooks); ?>)
                </div>
                <div class="overdue-dropdown-content">
                    <?php foreach ($overdueBooks as $book) : ?>
                    <div class="overdue-item">
                        <div class="overdue-item-title"><?php echo htmlspecialchars($book['title']); ?></div>
                        <div class="overdue-item-info">Borrowed by: <?php echo htmlspecialchars($book['name']); ?></div>
                        <div class="overdue-item-date">Due date: <?php echo htmlspecialchars($book['due_date']); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="dashboard-metrics-grid">
        <div class="dashboard-metric-card total-books">
            <div class="dashboard-metric-header">
                <div class="dashboard-metric-title">BORROWED BOOKS</div>
                <div class="dashboard-metric-icon">
                    <i class="fas fa-book-reader"></i>
                </div>
            </div>
            <div class="dashboard-metric-value"><?php echo number_format($borrowedBooksCount); ?></div>
            <a href="ldr_lenderForm.php" class="dashboard-metric-link">
                VIEW MORE <i class="fas fa-arrow-right"></i>
            </a>
        </div>

        <div class="dashboard-metric-card borrowed">
            <div class="dashboard-metric-header">
                <div class="dashboard-metric-title">RETURNED BOOKS</div>
                <div class="dashboard-metric-icon">
                    <i class="fas fa-undo"></i>
                </div>
            </div>
            <div class="dashboard-metric-value"><?php echo number_format($returnedBooksCount); ?></div>
            <a href="ldr_returnedForm.php" class="dashboard-metric-link">
                VIEW MORE <i class="fas fa-arrow-right"></i>
            </a>
        </div>

        <div class="dashboard-metric-card returned">
            <div class="dashboard-metric-header">
                <div class="dashboard-metric-title">TOTAL MEMBERS</div>
                <div class="dashboard-metric-icon">
                    <i class="fa-regular fa-user"></i>
                </div>
            </div>
            <div class="dashboard-metric-value"><?php echo number_format($total_members); ?></div>
            <a href="ldr_members.php" class="dashboard-metric-link">
                VIEW MORE <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="dashboard-table-container">
        <div class="dashboard-table-title">Recently Borrowed Books</div>
        <table class="dashboard-responsive-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Book Title</th>
                    <th>Borrow Date</th>
                    <th>Due Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($borrowedBooks as $book): ?>
                <tr>
                    <td><?php echo htmlspecialchars($book['name']); ?></td>
                    <td><?php echo htmlspecialchars($book['title']); ?></td>
                    <td><?php echo date('M d, Y', strtotime($book['borrow_date'])); ?></td>
                    <td><?php echo date('M d, Y', strtotime($book['due_date'])); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($borrowedBooks)): ?>
                <tr>
                    <td colspan="4" style="text-align: center;">No borrowed books found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const notification = document.getElementById('overdueNotification');
    const dropdown = document.getElementById('overdueDropdown');

    notification.addEventListener('click', function(e) {
        dropdown.classList.toggle('show');
        e.stopPropagation();
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!notification.contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });
});
</script>

</body>
</html>
