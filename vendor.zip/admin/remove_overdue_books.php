<?php
include('../config/connect.php');

// Get the current date
$current_date = date('Y-m-d');

// Query to select overdue books
$sql = "
    SELECT bb.book_id, bb.due_date, bb.book_type
    FROM borrowed_books bb
    WHERE bb.status = 'borrowed' AND bb.due_date < ?
";

// Prepare and execute the query
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $current_date);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are overdue books
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $book_id = $row['book_id'];
        $book_type = $row['book_type'];

        // If the book is overdue, delete it from borrowed_books
        $delete_sql = "DELETE FROM borrowed_books WHERE book_id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $book_id);
        $delete_stmt->execute();

        // If the book is an ebook, update its status in manage_books to 'available'
        if ($book_type == 'ebook') {
            $update_book_sql = "UPDATE manage_books SET status = 'available' WHERE book_id = ?";
            $update_book_stmt = $conn->prepare($update_book_sql);
            $update_book_stmt->bind_param("i", $book_id);
            $update_book_stmt->execute();
        }
    }

    echo "Overdue books status updated.";
} else {
    echo "No overdue books found.";
}

$conn->close();
?>
