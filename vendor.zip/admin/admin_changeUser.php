<?php
session_start();

header("Content-Type: application/json");

if (!isset($_SESSION['member_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents("php://input"), true);

if (isset($input['member_id']) && isset($input['status'])) {
    $memberId = $input['member_id'];
    $status = $input['status'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "library_db";

    $connection = new mysqli($servername, $username, $password, $database);

    if ($connection->connect_error) {
        echo json_encode(['success' => false, 'message' => 'Connection failed']);
        exit();
    }

    $stmt = $connection->prepare("UPDATE user_info SET status = ? WHERE member_id = ?");
    $stmt->bind_param("si", $status, $memberId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update status']);
    }

    $stmt->close();
    $connection->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
}
?>
